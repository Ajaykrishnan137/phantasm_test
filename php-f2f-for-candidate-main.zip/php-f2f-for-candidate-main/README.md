The following two APIs are required for development (no UI implementation needed; please demonstrate functionality using Postman):

1. Implement JWT authentication for user access.
2. Create an API endpoint to add a product to the cart.

Develop at: 
```
https://github.com/Phantasm-Solutions-Ltd-Pvt/php-f2f-for-candidate

```
Please ensure these implementations are set up prior to joining, in order to streamline the face-to-face interview process.

Best regards,  
Phantasm